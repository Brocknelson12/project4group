
public class MdsDriver {
	public static void main(String[] args){
		InputWindowsView input = new InputWindowsView();
		MediaModel model = new MediaModel();
		Controller controller = new Controller();
		controller.setView(input);
		controller.setModel(model);
		input.setModel(model);
		
	}
}
	
