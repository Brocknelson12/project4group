import java.io.Serializable;
import java.util.ArrayList;

/**
 * Project #3
 * CS 2334, Section 010
 * Mar 26, 2016
 * <P>
 * Class for storing information about a single movie
 * </P>
 */
public class Movie extends Show implements Serializable{
	
	/** SerialID that lets us implement Serializable */
	private static final long serialVersionUID = 1L;
	
	/**List to store any extra info about the movie*/
	
	private String name;
	private String year;
	private String roman;
	private String venue;
	/**Constructor for movie
	 * 
	 * @param name Name of movie
	 * @param year Year movie was released
	 * @param extraInfo Extra info about the movie
	 */
	public Movie(String name,String year, String roman, String venue) {
		super(name, year, year);
		this.name = name;
		this.year = year;
		this.roman = roman;
		this.venue = venue;
	}
	
	public Movie(String name,String year, String venue) {
		super(name, year, year);
		this.name = name;
		this.year = year;
		this.venue = venue;
	}

	/**Return string version of this movie
	@Override
	*/
	public String isEmpty(String roman){
		if(roman.isEmpty()){
			return "" ;
		}
		else{
			return "/" + roman;
		}
	}
	public String toString(){
		
return "MOVIE: " + name + " " + "(" + year + ")" + isEmpty(roman) + "	" + venue; 
	}
}
