import java.awt.Color;

/**
 * Project #3
 * CS 2334, Section 010
 * Mar 26, 2016
 * <P>
 * Class for making a slice of the pie
 * </P>
 */
public class Slice {
	double value;
	  Color color;

	  public Slice(double value, Color color){
		  this.value = value;
		  this.color = color;
	  }
}
